# Template de slides (metropolis)

Template de apresentações em beamer com o tema `metropolis` e paleta verde
customizada. Substitui o antigo template com a barra verde do IFSC.

## Como usar no Overleaf
1. Novo Projeto, Upload Project, selecione este `.zip`.
2. Documento principal: `apresentacao.tex`.
3. Compilador: **pdfLaTeX**. Funciona também com XeLaTeX/LuaLaTeX, que carregam
   as fontes Fira originais do metropolis. Nesse caso remova as linhas
   `\usepackage[utf8]{inputenc}`, `\usepackage[T1]{fontenc}` e
   `\usepackage{lmodern}`.

## Como usar localmente
```bash
pdflatex apresentacao.tex && pdflatex apresentacao.tex
```
A segunda passada é necessária para o sumário.

## O que ajustar
- `\title`, `\subtitle`, `\author`, `\institute`, `\date`.
- A paleta, nas três cores no topo do arquivo:
  `mPrimary`, `mPrimaryLight` e `mPrimaryDark`. Trocar essas cores muda a
  identidade visual inteira.

## Recursos
- Barra de título escura, barra de progresso e slide de seção do metropolis.
- Blocos (`block`), colunas, tabelas com `booktabs`.
- Atalhos `\kpi{Título}{Valor}` e `\placeholderimage`.

## Dependências
Nenhuma além de uma distribuição TeX com o pacote `beamertheme-metropolis`.
