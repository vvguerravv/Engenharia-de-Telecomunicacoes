# Tema Beamer — metropolis customizado (paleta verde)

## Como usar no Overleaf
1. Novo Projeto -> Upload Project -> selecione este `.zip`.
2. Documento principal: `main.tex`.
3. Compilador: **pdfLaTeX** (Menu -> Compiler). Funciona também com XeLaTeX/LuaLaTeX,
   que carregam as fontes Fira originais do metropolis — nesse caso remova as linhas
   `\usepackage[utf8]{inputenc}` e `\usepackage[T1]{fontenc}`.

## O que ajustar
- **Metadados**: `\title`, `\subtitle`, `\author`, `\institute`, `\date`.
- **Paleta**: as cores `mPrimary`, `mPrimaryLight` e `mPrimaryDark` no preâmbulo —
  trocar esses três HTML muda o tema inteiro (barra de progresso, blocos, marcadores).

## Conteúdo
`main.tex` traz o preâmbulo do tema e frames de exemplo: capa, sumário, itemize,
bloco + colunas com `\kpi`/`\placeholderimage`, tabela e encerramento.
